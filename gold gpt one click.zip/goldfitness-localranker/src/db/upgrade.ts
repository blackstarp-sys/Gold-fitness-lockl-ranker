import { readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
export async function upgradeDatabase(client: { query: (sql: string, params?: any[]) => Promise<any> }) {
  const dir = path.resolve('database/baseline');
  const baseline = readFileSync(path.join(dir, readdirSync(dir).find(f => f.endsWith('.sql'))!), 'utf8');
  const statements = baseline.split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean);
  await client.query('BEGIN');
  try {
    await client.query('SELECT pg_advisory_xact_lock(872160)');
    // Create absent tables first; foreign keys are added after all conversions.
    for (const statement of statements.filter(s => s.startsWith('CREATE TABLE'))) {
      await client.query(statement.replace('CREATE TABLE ', 'CREATE TABLE IF NOT EXISTS '));
    }
    const allowed = new Set(['business_locations','reviews','scheduled_posts','metric_logs','seo_keywords','competitors','citation_sources','campaigns','seo_audits']);
    for (const table of ['business_locations', 'reviews', 'scheduled_posts']) {
      const type = await client.query("SELECT data_type FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 AND column_name='id'", [table]);
      if (type.rows[0]?.data_type === 'uuid') continue;
      if (!['integer', 'bigint'].includes(type.rows[0]?.data_type)) throw new Error(`Unsupported ID type for ${table}; migration rolled back.`);
      const references = await client.query(`SELECT c.conname, t.relname AS child, a.attname AS column_name
        FROM pg_constraint c JOIN pg_class t ON t.oid=c.conrelid
        JOIN pg_attribute a ON a.attrelid=c.conrelid AND a.attnum=c.conkey[1]
        WHERE c.contype='f' AND c.confrelid=$1::regclass`, [table]);
      if (references.rows.some((r: any) => !allowed.has(r.child))) throw new Error(`Custom tables reference ${table}. Review a custom migration before proceeding.`);
      for (const ref of references.rows) await client.query(`ALTER TABLE "${ref.child}" DROP CONSTRAINT "${ref.conname}"`);
      await client.query(`CREATE TEMP TABLE "map_${table}" ON COMMIT DROP AS SELECT id AS old_id, gen_random_uuid() AS new_id FROM "${table}"`);
      await client.query(`CREATE OR REPLACE FUNCTION pg_temp.map_${table}(bigint) RETURNS uuid LANGUAGE SQL STABLE AS 'SELECT new_id FROM "map_${table}" WHERE old_id = $1'`);
      // Includes newly created tables whose FK is not installed yet; those already use UUID.
      const children = table === 'business_locations' ? ['reviews','scheduled_posts','metric_logs','seo_keywords','competitors','citation_sources','campaigns','seo_audits'] : [];
      for (const child of children) {
        const col = await client.query("SELECT data_type FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 AND column_name='location_id'", [child]);
        if (col.rows[0]?.data_type !== 'uuid') await client.query(`ALTER TABLE "${child}" ALTER COLUMN location_id TYPE uuid USING pg_temp.map_${table}(location_id::bigint)`);
      }
      await client.query(`ALTER TABLE "${table}" ALTER COLUMN id DROP DEFAULT`);
      await client.query(`ALTER TABLE "${table}" ALTER COLUMN id TYPE uuid USING pg_temp.map_${table}(id::bigint)`);
      await client.query(`ALTER TABLE "${table}" ALTER COLUMN id SET DEFAULT gen_random_uuid()`);
    }
    for (const statement of statements.filter(s => s.startsWith('CREATE TABLE'))) {
      const table = statement.match(/CREATE TABLE "([^"]+)"/)![1];
      for (const line of statement.split('\n').slice(1, -1)) {
        const definition = line.trim().replace(/,$/, '');
        if (!definition.startsWith('"')) continue;
        const column = definition.match(/^"([^"]+)"/)![1];
        const existing = await client.query("SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 AND column_name=$2", [table, column]);
        if (!existing.rows.length) await client.query(`ALTER TABLE "${table}" ADD COLUMN ${definition}`);
      }
    }
    for (const statement of statements.filter(s => s.startsWith('ALTER TABLE'))) {
      const name = statement.match(/ADD CONSTRAINT "([^"]+)"/)?.[1];
      const table = statement.match(/ALTER TABLE "([^"]+)"/)?.[1];
      if (!name || !table) continue;
      const existing = await client.query('SELECT 1 FROM pg_constraint WHERE conname=$1 AND conrelid=$2::regclass', [name, table]);
      if (!existing.rows.length) await client.query(statement);
    }
    await client.query('COMMIT');
  } catch (error) { await client.query('ROLLBACK'); throw error; }
}
