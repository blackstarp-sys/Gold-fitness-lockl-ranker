import { createPool } from './index.ts';
import { upgradeDatabase } from './upgrade.ts';
const pool = createPool();
const client = await pool.connect();
try { await upgradeDatabase(client); console.log('Database schema ready. Existing rows preserved.'); }
catch (error) { console.error(error); process.exitCode = 1; }
finally { client.release(); await pool.end(); }
