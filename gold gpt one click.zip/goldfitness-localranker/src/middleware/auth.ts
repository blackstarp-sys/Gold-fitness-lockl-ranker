import { Request, Response, NextFunction } from 'express';
import { adminAuth } from '../lib/firebase-admin.ts';
import { DecodedIdToken } from 'firebase-admin/auth';
import { db } from '../db/index.ts';
import { users } from '../db/schema.ts';
import { eq } from 'drizzle-orm';

export interface AuthRequest extends Request {
  user?: DecodedIdToken;
  dbUser?: any;
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing token' });
  }

  const token = authHeader.split('Bearer ')[1];
  let decodedToken: DecodedIdToken;
  try {
    decodedToken = await adminAuth.verifyIdToken(token);
  } catch {
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
  try {
    req.user = decodedToken;
    
    // Get user from DB
    let userRecords = await db.select().from(users).where(eq(users.uid, decodedToken.uid));
    
    if (userRecords.length > 0) {
      req.dbUser = userRecords[0];
    } else {
      // Upsert
      const newUser = await db.insert(users).values({
        uid: decodedToken.uid,
        email: decodedToken.email || '',
        name: decodedToken.name || '',
      }).onConflictDoUpdate({
        target: users.uid,
        set: {
          email: decodedToken.email || '',
          name: decodedToken.name || '',
        }
      }).returning();
      req.dbUser = newUser[0];
    }
    
    next();
  } catch (error) {
    console.error('Account database unavailable');
    return res.status(503).json({ error: 'Account service unavailable. Please retry.', code: 'DATABASE_UNAVAILABLE' });
  }
};
