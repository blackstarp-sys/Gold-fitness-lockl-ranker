import { resolve4 } from 'node:dns/promises';
import https from 'node:https';
import http from 'node:http';
export function isPublicIPv4(ip: string) {
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return false;
  const [a,b,c] = p;
  return !(a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && (b === 168 || b === 0 || (b === 88 && c === 99))) || (a === 100 && b >= 64 && b <= 127) || (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) || (a === 203 && b === 0 && c === 113));
}
export async function fetchPublicPage(raw: string, redirects = 0): Promise<{ html: string; url: string }> {
  const url = new URL(raw);
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || (url.port && !['80', '443'].includes(url.port))) throw Object.assign(new Error('Use a public HTTP(S) website on its standard port.'), { status: 400 });
  if (redirects > 4) throw new Error('Too many website redirects.');
  const addresses = await resolve4(url.hostname);
  if (!addresses.length || addresses.some(ip => !isPublicIPv4(ip))) throw Object.assign(new Error('Private and reserved network addresses cannot be audited.'), { status: 400 });
  // Pin the checked DNS result to prevent rebinding between validation and connection.
  const response = await new Promise<{ status: number; location?: string; html: string }>((resolve, reject) => {
    const client = url.protocol === 'https:' ? https : http;
    const request = client.get(url, { family: 4, lookup: ((_host: any, options: any, callback: any) => options?.all ? callback(null, [{ address: addresses[0], family: 4 }]) : callback(null, addresses[0], 4)) as any, headers: { 'User-Agent': 'GoldFitnessSEOAudit/1.0', Accept: 'text/html', 'Accept-Encoding': 'identity' } }, result => {
      const chunks: Buffer[] = []; let size = 0;
      result.on('data', chunk => { size += chunk.length; if (size > 1024 * 1024) { request.destroy(new Error('Page exceeds the 1 MB audit limit.')); } else chunks.push(chunk); });
      result.on('error', reject);
      result.on('end', () => resolve({ status: result.statusCode || 500, location: result.headers.location, html: Buffer.concat(chunks).toString('utf8') }));
    });
    const timer = setTimeout(() => request.destroy(new Error('Website audit timed out.')), 10000);
    request.on('close', () => clearTimeout(timer)); request.on('error', reject);
  });
  if (response.status >= 300 && response.status < 400 && response.location) return fetchPublicPage(new URL(response.location, url).href, redirects + 1);
  if (response.status < 200 || response.status >= 300) throw new Error(`Website returned HTTP ${response.status}.`);
  return { html: response.html, url: url.href };
}
export function analyzeHtml(html: string, url: string) {
  const title = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || '';
  const h1Count = (html.match(/<h1(?:\s|>)/gi) || []).length;
  const metaTags = html.match(/<meta\b[^>]*>/gi) || [];
  const hasMeta = (name: string) => metaTags.some(tag => new RegExp(`name\\s*=\\s*["']${name}["']`, 'i').test(tag) && /content\s*=\s*["'][^"']+/i.test(tag));
  const checks = [
    { key: 'https', passed: url.startsWith('https:'), title: 'HTTPS connection' },
    { key: 'title', passed: title.length >= 15 && title.length <= 65, title: 'Title length between 15 and 65 characters' },
    { key: 'description', passed: hasMeta('description'), title: 'Meta description' },
    { key: 'viewport', passed: hasMeta('viewport'), title: 'Mobile viewport' },
    { key: 'h1', passed: h1Count === 1, title: 'One primary H1 heading' },
    { key: 'canonical', passed: /<link\b[^>]*rel\s*=\s*["']canonical["']/i.test(html), title: 'Canonical URL declaration' },
    { key: 'structured-data', passed: /application\/ld\+json/i.test(html), title: 'Structured data declaration (validity not checked)' },
    { key: 'language', passed: /<html\b[^>]*lang\s*=/i.test(html), title: 'Document language' },
  ];
  return { url, title, h1Count, score: Math.round(checks.filter(c => c.passed).length / checks.length * 100), checks, scope: 'Basic HTML checks, not a ranking or Core Web Vitals score.' };
}
