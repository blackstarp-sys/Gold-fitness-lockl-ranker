export function normalizePerformance(data: any) {
  const days = new Map<string, any>();
  for (const group of data.multiDailyMetricTimeSeries || []) {
    for (const series of group.dailyMetricTimeSeries || []) {
      for (const item of series.timeSeries?.datedValues || []) {
        const d = item.date;
        if (!d?.year || !d?.month || !d?.day) continue;
        const date = new Date(Date.UTC(d.year, d.month - 1, d.day));
        const key = date.toISOString();
        const row = days.get(key) || { recordedDate: date, profileViews: 0, searchViews: 0, searchesMaps: 0, websiteClicks: 0, callClicks: 0 };
        const value = Math.max(0, Number(item.value) || 0);
        if (series.dailyMetric === 'WEBSITE_CLICKS') row.websiteClicks += value;
        if (series.dailyMetric === 'CALL_CLICKS') row.callClicks += value;
        if (series.dailyMetric?.startsWith('BUSINESS_IMPRESSIONS_')) {
          row.profileViews += value;
          if (series.dailyMetric.endsWith('_MAPS')) row.searchesMaps += value;
          if (series.dailyMetric.endsWith('_SEARCH')) row.searchViews += value;
        }
        days.set(key, row);
      }
    }
  }
  return [...days.values()].sort((a,b) => a.recordedDate.getTime() - b.recordedDate.getTime());
}
