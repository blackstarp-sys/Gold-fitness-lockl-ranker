import { fetchPublicPage, analyzeHtml } from './websiteAudit.ts';
import type { Express } from 'express';
import { and, eq, desc, sql, inArray } from 'drizzle-orm';
import { db } from '../db/index.ts';
import { businessLocations, reviews, scheduledPosts, appSettings, notifications, auditLogs, seoAudits, seoAuditItems, seoKeywords, competitors, citationSources, campaigns } from '../db/schema.ts';
import { requireAuth, type AuthRequest } from '../middleware/auth.ts';
import { generateStudioContent } from '../lib/gemini.ts';
import { profileChecks } from './validation.ts';
export function registerFeatures(app: Express, charge: (userId: number, amount: number, feature: string, description: string) => Promise<number>) {
  const collections = [
    { path: '/api/seo/keywords', table: seoKeywords, field: 'keyword' },
    { path: '/api/competitors', table: competitors, field: 'businessName' },
    { path: '/api/citations', table: citationSources, field: 'platform' },
    { path: '/api/campaigns', table: campaigns, field: 'name' },
  ];
  for (const collection of collections) {
    const table: any = collection.table;
    app.post(collection.path, requireAuth, async (req: AuthRequest, res) => {
      const { locationId, value } = req.body;
      if (typeof locationId !== 'string' || !/^[0-9a-f-]{36}$/i.test(locationId) || typeof value !== 'string' || !value.trim() || value.length > 200) return res.status(400).json({ message: 'Select a location and enter a value up to 200 characters.' });
      const [location] = await db.select().from(businessLocations).where(and(eq(businessLocations.id, locationId), eq(businessLocations.userId, req.dbUser.id)));
      if (!location) return res.status(404).json({ message: 'Location not found.' });
      const values: any = { locationId, [collection.field]: value.trim() };
      if (collection.path === '/api/campaigns') Object.assign(values, { type: 'WHATSAPP', status: 'DRAFT', messageTemplate: typeof req.body.messageTemplate === 'string' ? req.body.messageTemplate.slice(0, 4000) : '' });
      const rows = await db.insert(table).values(values).returning() as any[];
      const row = rows[0];
      res.json(row);
    });
    app.delete(collection.path + '/:id', requireAuth, async (req: AuthRequest, res) => {
      const id = Number(req.params.id);
      if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ message: 'Invalid record ID.' });
      const ownedLocations = db.select({ id: businessLocations.id }).from(businessLocations).where(eq(businessLocations.userId, req.dbUser.id));
      const rows = await db.delete(table).where(and(eq(table.id, id), inArray(table.locationId, ownedLocations))).returning({ id: table.id });
      if (!rows.length) return res.status(404).json({ message: 'Record not found.' });
      res.json({ success: true });
    });
  }
  app.get('/api/settings/templates', requireAuth, async (req: AuthRequest, res) => {
    const rows = await db.select().from(appSettings).where(and(eq(appSettings.userId, req.dbUser.id), eq(appSettings.key, 'reply_template'))).orderBy(desc(appSettings.updatedAt));
    res.json(rows.map(r => ({ ...(r.value as object), id: r.id })));
  });
  app.post('/api/settings/templates', requireAuth, async (req: AuthRequest, res) => {
    const { name, text, ratingTarget } = req.body;
    if (typeof name !== 'string' || !name.trim() || name.length > 100 || typeof text !== 'string' || !text.trim() || text.length > 4000) return res.status(400).json({ message: 'Template name and text are required (100 and 4000 characters maximum).' });
    const [row] = await db.insert(appSettings).values({ userId: req.dbUser.id, key: 'reply_template', value: { name, text, ratingTarget } }).returning();
    res.json({ ...(row.value as object), id: row.id });
  });
  app.delete('/api/settings/templates/:id', requireAuth, async (req: AuthRequest, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ message: 'Invalid template ID.' });
    const deleted = await db.delete(appSettings).where(and(eq(appSettings.id, id), eq(appSettings.userId, req.dbUser.id), eq(appSettings.key, 'reply_template'))).returning({ id: appSettings.id });
    if (!deleted.length) return res.status(404).json({ message: 'Template not found.' });
    res.json({ success: true });
  });
  app.get('/api/ai/studio', requireAuth, async (req: AuthRequest, res) => {
    const rows = await db.select().from(appSettings).where(and(eq(appSettings.userId, req.dbUser.id), eq(appSettings.key, 'ai_draft'))).orderBy(desc(appSettings.updatedAt)).limit(50);
    res.json(rows.map(r => ({ id: r.id, ...(r.value as object), createdAt: r.updatedAt })));
  });
  const active = new Set<number>();
  app.post('/api/ai/studio', requireAuth, async (req: AuthRequest, res) => {
    const { topic, kind = 'Google Business post', language = 'English' } = req.body;
    if (typeof topic !== 'string' || !topic.trim() || topic.length > 4000 || typeof kind !== 'string' || kind.length > 80 || typeof language !== 'string' || language.length > 40) return res.status(400).json({ message: 'Provide a topic (up to 4000 characters), content type and language.' });
    const userId = req.dbUser.id;
    if (active.has(userId)) return res.status(429).json({ message: 'A draft is already being generated. Please wait.' });
    active.add(userId);
    try {
      const content = await generateStudioContent(topic.trim(), kind, language);
      await charge(userId, 2, 'AI_STUDIO', topic.slice(0, 80));
      const [row] = await db.insert(appSettings).values({ userId, key: 'ai_draft', value: { title: topic.slice(0, 100), kind, language, content } }).returning();
      res.json({ id: row.id, ...(row.value as object), createdAt: row.updatedAt });
    } finally { active.delete(userId); }
  });
  app.post('/api/optimization/run', requireAuth, async (req: AuthRequest, res) => {
    const userId = req.dbUser.id;
    const locations = await db.select().from(businessLocations).where(eq(businessLocations.userId, userId));
    if (!locations.length) return res.status(409).json({ message: 'Connect and sync your Google Business location first.' });
    const results = [];
    for (const location of locations) {
      const locationReviews = await db.select({ replied: reviews.isReplied }).from(reviews).where(eq(reviews.locationId, location.id));
      const posts = await db.select({ status: scheduledPosts.status, publishedAt: scheduledPosts.publishedAt }).from(scheduledPosts).where(eq(scheduledPosts.locationId, location.id));
      const unanswered = locationReviews.filter(r => !r.replied).length;
      const recent = posts.filter(p => p.status === 'PUBLISHED' && p.publishedAt && p.publishedAt.getTime() > Date.now() - 7 * 86400000).length;
      results.push({ locationId: location.id, businessName: location.businessName, unansweredReviews: unanswered, ...profileChecks(location, unanswered, recent) });
    }
    const report = { generatedAt: new Date().toISOString(), source: 'Saved profile and synced activity; completeness score is not a Google ranking.', locations: results };
    await db.transaction(async tx => {
      await tx.insert(appSettings).values({ userId, key: 'optimization_report', value: report });
      await tx.insert(auditLogs).values({ userId, action: 'OPTIMIZATION_CHECK', metadata: { locations: results.length } });
      await tx.insert(notifications).values({ userId, title: 'Optimization checklist ready', message: `Checked ${results.length} location(s). Open One-click Optimization to review your next actions.` });
    });
    res.json(report);
  });
  app.get('/api/optimization/latest', requireAuth, async (req: AuthRequest, res) => {
    const [row] = await db.select().from(appSettings).where(and(eq(appSettings.userId, req.dbUser.id), eq(appSettings.key, 'optimization_report'))).orderBy(desc(appSettings.updatedAt)).limit(1);
    res.json(row?.value || null);
  });
  app.post('/api/seo/audit', requireAuth, async (req: AuthRequest, res) => {
    const { locationId } = req.body;
    if (typeof locationId !== 'string' || !/^[0-9a-f-]{36}$/i.test(locationId)) return res.status(400).json({ message: 'Select a business location.' });
    const [location] = await db.select().from(businessLocations).where(and(eq(businessLocations.id, locationId), eq(businessLocations.userId, req.dbUser.id)));
    if (!location) return res.status(404).json({ message: 'Location not found.' });
    if (!location.websiteUri) return res.status(409).json({ message: 'Save the business website URL in your profile first.' });
    const page = await fetchPublicPage(location.websiteUri);
    const result = analyzeHtml(page.html, page.url);
    const audit = await db.transaction(async tx => {
      const [row] = await tx.insert(seoAudits).values({ locationId, url: result.url, score: result.score }).returning();
      await tx.insert(seoAuditItems).values(result.checks.map(c => ({ auditId: row.id, checkKey: c.key, status: c.passed ? 'PASS' : 'WARNING', message: c.title })));
      return row;
    });
    res.json({ ...audit, ...result });
  });
  app.get('/api/seo/audit/:id', requireAuth, async (req: AuthRequest, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ message: 'Invalid audit ID.' });
    const [row] = await db.select({ id: seoAudits.id }).from(seoAudits).innerJoin(businessLocations, eq(seoAudits.locationId, businessLocations.id)).where(and(eq(seoAudits.id, id), eq(businessLocations.userId, req.dbUser.id)));
    if (!row) return res.status(404).json({ message: 'Audit not found.' });
    res.json(await db.select().from(seoAuditItems).where(eq(seoAuditItems.auditId, id)));
  });
  app.get('/api/notifications', requireAuth, async (req: AuthRequest, res) => {
    res.json(await db.select().from(notifications).where(eq(notifications.userId, req.dbUser.id)).orderBy(desc(notifications.createdAt)).limit(100));
  });
  app.post('/api/notifications/read-all', requireAuth, async (req: AuthRequest, res) => {
    await db.update(notifications).set({ read: true }).where(eq(notifications.userId, req.dbUser.id));
    res.json({ success: true });
  });
  app.delete('/api/notifications/:id', requireAuth, async (req: AuthRequest, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ message: 'Invalid notification ID.' });
    const rows = await db.delete(notifications).where(and(eq(notifications.id, id), eq(notifications.userId, req.dbUser.id))).returning({ id: notifications.id });
    if (!rows.length) return res.status(404).json({ message: 'Notification not found.' });
    res.json({ success: true });
  });
}
