import { randomBytes, createHash } from 'node:crypto';
import type { Request, Response } from 'express';
import { and, eq, gt, lt } from 'drizzle-orm';
import { db } from '../db/index.ts';
import { appSettings } from '../db/schema.ts';
const cookieName = 'google_oauth_state';
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
export async function issueOAuthState(userId: number, req: Request, res: Response) {
  const nonce = randomBytes(32).toString('hex');
  // Random, server-held state cannot be edited to select another user.
  await db.delete(appSettings).where(and(eq(appSettings.key, 'oauth_state'), lt(appSettings.updatedAt, new Date(Date.now() - 600000))));
  await db.insert(appSettings).values({ userId, key: 'oauth_state', value: digest(nonce) });
  res.cookie(cookieName, nonce, { httpOnly: true, sameSite: 'lax', secure: req.secure || process.env.NODE_ENV === 'production', maxAge: 600000, path: '/api/google' });
  return nonce;
}
export async function consumeOAuthState(state: unknown, req: Request, res: Response): Promise<number | null> {
  const cookie = req.headers.cookie?.split(';').map(v => v.trim()).find(v => v.startsWith(cookieName + '='))?.slice(cookieName.length + 1);
  res.clearCookie(cookieName, { path: '/api/google' });
  if (typeof state !== 'string' || !/^[a-f0-9]{64}$/.test(state) || cookie !== state) return null;
  const records = await db.delete(appSettings).where(and(eq(appSettings.key, 'oauth_state'), eq(appSettings.value, digest(state)), gt(appSettings.updatedAt, new Date(Date.now() - 600000)))).returning({ userId: appSettings.userId });
  return records[0]?.userId || null;
}
