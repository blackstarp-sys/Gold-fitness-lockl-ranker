export function validatePost(body: any, scheduled = false): string | null {
  if (!body || typeof body.summary !== 'string' || !body.summary.trim() || body.summary.length > 1500) return 'Post content must contain 1–1500 characters.';
  if (typeof body.locationId !== 'string' || !/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(body.locationId)) return 'A valid location ID is required.';
  if (body.mediaUrl) {
    try { if (new URL(body.mediaUrl).protocol !== 'https:') return 'Image URL must use HTTPS.'; } catch { return 'Image URL is invalid.'; }
  }
  if (scheduled && (!body.scheduledFor || !Number.isFinite(Date.parse(body.scheduledFor)) || Date.parse(body.scheduledFor) <= Date.now())) return 'Choose a valid future date and time.';
  if (body.platforms && (!Array.isArray(body.platforms) || body.platforms.length !== 1 || body.platforms[0] !== 'google')) return 'Only Google publishing is supported. Other platforms are not connected.';
  return null;
}
export function profileChecks(location: any, unanswered: number, recentPosts: number) {
  const values = [
    ['name', 'Business name', !!location.businessName?.trim(), '/google-business'],
    ['address', 'Business address', !!location.address?.trim(), '/google-business'],
    ['phone', 'Contact phone', !!location.phone?.trim(), '/google-business'],
    ['website', 'Website link', /^https:\/\//.test(location.websiteUri || ''), '/google-business'],
    ['description', 'Business description', (location.description?.trim().length || 0) >= 100, '/google-business'],
    ['category', 'Business category', !!location.category?.trim(), '/google-business'],
    ['hours', 'Opening hours', !!location.businessHours && JSON.stringify(location.businessHours).length > 2, '/google-business'],
    ['reviews', 'Reply to all reviews', unanswered === 0, '/reviews'],
    ['posts', 'Post in the last 7 days', recentPosts > 0, '/google-posts'],
  ];
  const checks = values.map(([key, title, passed, href]) => ({ key, title, passed, href }));
  return { score: Math.round(checks.filter(c => c.passed).length / checks.length * 100), checks };
}
