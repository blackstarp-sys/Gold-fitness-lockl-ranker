import React from 'react';
import WhatsAppTemplateManager from '../components/WhatsAppTemplateManager.tsx';
export default function WhatsApp() { return <div className="space-y-6"><h1 className="text-3xl font-bold">WhatsApp Templates</h1><p className="text-muted">Create and save reusable message templates. These are local drafts, not Meta-approved templates. Message delivery and webhook processing are not implemented in this version.</p><WhatsAppTemplateManager /></div>; }
