import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.tsx';
export default function LocalRank() {
  const { apiFetch } = useAuth(); const [locations, setLocations] = useState<any[]>([]); const [error, setError] = useState('');
  useEffect(() => { apiFetch('/api/locations').then(setLocations).catch(e => setError(e.message)); }, [apiFetch]);
  return <div className="space-y-5"><h1 className="text-3xl font-bold">Local Visibility</h1><p className="text-muted">Automatic rank-grid measurements require a ranking provider integration. No measured grid ranks are available yet.</p>{error && <p role="alert">{error}</p>}{locations.map(l => <article key={l.id} className="bg-card p-6 rounded-xl"><h2 className="font-bold">{l.businessName}</h2><p>{l.address}</p><a className="text-primary" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(l.businessName + ' ' + (l.address || ''))}`}>Open business search in Google Maps</a></article>)}<Link className="text-primary" to="/keywords">View tracked keywords →</Link></div>;
}
