import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
export default function WebsiteAudit() {
  const { apiFetch } = useAuth(); const [audits, setAudits] = useState<any[]>([]); const [locations, setLocations] = useState<any[]>([]); const [selected, setSelected] = useState(''); const [details, setDetails] = useState<any[]>([]); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  useEffect(() => { Promise.all([apiFetch('/api/seo/audit'), apiFetch('/api/locations')]).then(([a, l]) => { setAudits(a); setLocations(l); setSelected(l[0]?.id || ''); }).catch(e => setError(e.message)); }, [apiFetch]);
  async function run() { setBusy(true); setError(''); try { const audit = await apiFetch('/api/seo/audit', { method: 'POST', body: JSON.stringify({ locationId: selected }) }); setAudits(a => [audit, ...a]); setDetails(audit.checks.map((c: any) => ({ id: c.key, status: c.passed ? 'PASS' : 'WARNING', message: c.title }))); } catch(e: any) { setError(e.message); } finally { setBusy(false); } }
  async function inspect(id: number) { try { setDetails(await apiFetch(`/api/seo/audit/${id}`)); } catch(e: any) { setError(e.message); } }
  return <div className="space-y-5 max-w-5xl mx-auto"><h1 className="text-3xl font-bold">Website Audit</h1><p className="text-muted">Basic checks of your saved website: title, description, mobile viewport, headings, canonical URL, language and structured data declarations. This does not measure search ranking or Core Web Vitals.</p>
    <label className="block">Business location<select className="bg-card border border-border rounded-xl p-3 block w-full" value={selected} onChange={e => setSelected(e.target.value)}>{locations.map(l => <option key={l.id} value={l.id}>{l.businessName} — {l.websiteUri || 'No website saved'}</option>)}</select></label>
    <button disabled={busy || !selected} onClick={run} className="bg-primary p-3 rounded-xl disabled:opacity-50">{busy ? 'Auditing…' : 'Start website audit'}</button>{error && <p className="text-danger" role="alert">{error}</p>}
    {details.length > 0 && <section className="bg-card border border-border rounded-xl p-5"><h2 className="text-xl font-bold">Audit findings</h2>{details.map(d => <p key={d.id} className="py-2">{d.status === 'PASS' ? '✓' : '○'} {d.message}</p>)}</section>}
    <h2 className="text-xl font-bold">Audit history</h2>{!audits.length && <p>No audits yet.</p>}{audits.map(a => <div key={a.id} className="flex flex-wrap justify-between gap-3 bg-card border border-border rounded-xl p-5"><span className="break-all">{a.url}</span><span>{a.score}% · {new Date(a.completedAt).toLocaleDateString()}</span><button onClick={() => inspect(a.id)} className="text-primary">Details</button></div>)}
  </div>;
}
