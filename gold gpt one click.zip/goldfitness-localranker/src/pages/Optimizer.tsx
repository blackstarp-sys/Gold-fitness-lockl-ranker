import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.tsx';
export default function Optimizer() {
  const { apiFetch } = useAuth();
  const [report, setReport] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { apiFetch('/api/optimization/latest').then(setReport).catch(e => setError(e.message)); }, [apiFetch]);
  async function run() {
    setBusy(true); setError('');
    try { setReport(await apiFetch('/api/optimization/run', { method: 'POST', body: '{}' })); }
    catch (e: any) { setError(e.message); } finally { setBusy(false); }
  }
  function download() {
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = 'optimization-report.json'; a.click(); URL.revokeObjectURL(url);
  }
  return <div className="space-y-6 max-w-5xl mx-auto">
    <h1 className="text-3xl font-bold">One-click Optimization</h1>
    <p className="text-muted">Check saved business details, review replies and posting activity. Get clear next actions for every location.</p>
    <div className="flex gap-3"><button disabled={busy} onClick={run} className="bg-primary rounded-xl p-4 font-bold disabled:opacity-50">{busy ? 'Checking…' : 'Run optimization check'}</button>{report && <button onClick={download} className="border border-border rounded-xl p-4">Export report</button>}</div>
    {error && <p role="alert" className="text-danger">{error}</p>}
    {!report && !busy && <p>Run your first check after connecting and syncing Google Business.</p>}
    {report && <><p className="text-sm text-muted">{report.source} Checked {new Date(report.generatedAt).toLocaleString()}.</p>{report.locations.map((location: any) => <section key={location.locationId} className="bg-card border border-border rounded-2xl p-6 space-y-4">
      <h2 className="text-xl font-bold">{location.businessName} · {location.score}% complete</h2>
      <div className="h-2 bg-background rounded"><div className="h-2 bg-primary rounded" style={{ width: `${location.score}%` }} /></div>
      {location.checks.map((check: any) => <div key={check.key} className="flex justify-between gap-4 border-b border-border py-3"><span>{check.passed ? '✓' : '○'} {check.title}</span>{!check.passed && <Link to={check.href} className="text-primary">Review and fix →</Link>}</div>)}
    </section>)}</>}
  </div>;
}
