import React from 'react';
import { Link } from 'react-router-dom';
export default function AIImageGen() { return <div className="space-y-5"><h1 className="text-3xl font-bold">AI Image Studio</h1><div className="bg-card border border-border rounded-xl p-6"><p>Image generation is not connected yet. This feature needs an image model, image storage and a publishing URL.</p><p className="text-muted mt-3">You can generate marketing text and campaign briefs in the AI Content Studio now.</p></div><Link to="/ai-mode" className="text-primary">Open AI Content Studio →</Link></div>; }
