import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.tsx';
export default function Billing() {
  const { apiFetch } = useAuth(); const [plan, setPlan] = useState(''); const [error, setError] = useState('');
  useEffect(() => { apiFetch('/api/billing/subscription').then(s => setPlan(s.plan)).catch(e => setError(e.message)); }, [apiFetch]);
  return <div className="space-y-5"><h1 className="text-3xl font-bold">Plan and Billing</h1>{error && <p role="alert">{error}</p>}<div className="bg-card border border-border p-6 rounded-xl"><p>AI credit plan: {plan || 'Loading…'}</p><p className="text-muted mt-3">Payment processing is not configured. No active payment method, invoice or renewal date is recorded by this app.</p></div><Link className="text-primary" to="/usage">View your AI credit usage →</Link></div>;
}
