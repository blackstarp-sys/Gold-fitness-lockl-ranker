import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.tsx';
export default function SocialConfig() {
  const { apiFetch } = useAuth(); const [accounts,setAccounts] = useState<any[]>([]); const [error,setError] = useState('');
  useEffect(()=>{apiFetch('/api/social-accounts').then(setAccounts).catch(e=>setError(e.message));},[apiFetch]);
  async function disconnect(id:number){try{await apiFetch(`/api/social-accounts/disconnect/${id}`,{method:'DELETE'});setAccounts(a=>a.filter(i=>i.id!==id));}catch(e:any){setError(e.message);}}
  return <div className="space-y-5"><h1 className="text-3xl font-bold">Social Connections</h1><p className="text-muted">Google Business authorization is available. Facebook, Instagram, LinkedIn and X publishing require separate OAuth integrations and are not implemented yet.</p><Link to="/google-business" className="text-primary">Manage Google Business connection →</Link>{error&&<p role="alert">{error}</p>}{accounts.map(a=><article key={a.id} className="bg-card rounded-xl p-5"><h2>{a.platformName}: {a.profileName}</h2><p className="text-muted">Saved connection — authorization not verified</p><button className="text-danger" onClick={()=>disconnect(a.id)}>Remove saved connection</button></article>)}</div>;
}
