import React from 'react';
import CollectionManager from '../components/CollectionManager.tsx';
export default function Competitors() { return <CollectionManager title="Competitors" path="/api/competitors" field="businessName" description="Keep a saved competitor list. Ratings and ranks are shown only when measured data has been imported." />; }
