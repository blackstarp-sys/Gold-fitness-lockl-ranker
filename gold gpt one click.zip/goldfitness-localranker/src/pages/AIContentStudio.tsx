import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
const kinds = ['Google Business post', 'Service description', 'Frequently asked questions', 'SEO keyword ideas', 'Weekly marketing plan'];
export default function AIContentStudio() {
  const { apiFetch } = useAuth();
  const [history, setHistory] = useState<any[]>([]);
  const [topic, setTopic] = useState(''); const [kind, setKind] = useState(kinds[0]);
  const [language, setLanguage] = useState('English'); const [content, setContent] = useState('');
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  useEffect(() => { apiFetch('/api/ai/studio').then(setHistory).catch(e => setError(e.message)); }, [apiFetch]);
  async function generate(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const draft = await apiFetch('/api/ai/studio', { method: 'POST', body: JSON.stringify({ topic, kind, language }) });
      setContent(draft.content); setHistory(h => [draft, ...h]);
    } catch (e: any) { setError(e.message); } finally { setBusy(false); }
  }
  return <div className="space-y-6 max-w-5xl mx-auto">
    <h1 className="text-3xl font-bold">AI Content Studio</h1><p className="text-muted">Create drafts using your business facts. Successful generations cost 2 credits. Review details before publishing.</p>
    {error && <p role="alert" className="text-danger">{error}</p>}
    <form onSubmit={generate} className="bg-card border border-border rounded-2xl p-6 space-y-4">
      <label className="block">Content type<select className="block bg-background p-3 rounded-xl w-full" value={kind} onChange={e => setKind(e.target.value)}>{kinds.map(k => <option key={k}>{k}</option>)}</select></label>
      <label className="block">Language<select className="block bg-background p-3 rounded-xl w-full" value={language} onChange={e => setLanguage(e.target.value)}>{['English', 'Kannada', 'Hindi'].map(l => <option key={l}>{l}</option>)}</select></label>
      <label className="block">Business facts and topic<textarea required maxLength={4000} rows={4} className="block bg-background p-3 rounded-xl w-full" value={topic} onChange={e => setTopic(e.target.value)} placeholder="Business name, location, service, audience and confirmed offer details" /></label>
      <button disabled={busy || !topic.trim()} className="bg-primary p-3 rounded-xl font-bold disabled:opacity-50">{busy ? 'Generating…' : 'Generate draft'}</button>
    </form>
    {content && <section className="bg-card border border-border rounded-2xl p-6 space-y-3"><h2 className="font-bold text-xl">Your editable draft</h2><textarea aria-label="Generated draft" rows={12} className="bg-background p-3 w-full rounded-xl" value={content} onChange={e => setContent(e.target.value)} /><button className="text-primary" onClick={async () => { try { await navigator.clipboard.writeText(content); } catch { setError('Clipboard unavailable. Select and copy the draft manually.'); } }}>Copy draft</button></section>}
    <h2 className="text-xl font-bold">Saved generation history</h2>{!history.length && <p className="text-muted">No drafts yet.</p>}
    {history.map(item => <button key={item.id} onClick={() => setContent(item.content)} className="block w-full text-left bg-card p-4 rounded-xl border border-border"><strong>{item.title}</strong><span className="block text-muted text-sm">{item.kind} · {new Date(item.createdAt).toLocaleString()}</span></button>)}
  </div>;
}
