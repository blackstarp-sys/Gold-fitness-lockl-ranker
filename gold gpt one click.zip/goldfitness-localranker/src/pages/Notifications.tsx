import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
export default function Notifications() {
  const { apiFetch } = useAuth(); const [items, setItems] = useState<any[]>([]); const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  const load = () => apiFetch('/api/notifications').then(setItems).catch(e => setError(e.message));
  useEffect(() => { load(); }, [apiFetch]);
  async function action(path: string, method: string) { setBusy(true); setError(''); try { await apiFetch(path, { method }); await load(); } catch(e: any) { setError(e.message); } finally { setBusy(false); } }
  return <div className="space-y-5 max-w-4xl mx-auto"><h1 className="text-3xl font-bold">Notifications</h1><button disabled={busy} onClick={() => action('/api/notifications/read-all', 'POST')} className="bg-primary p-3 rounded-xl">Mark all as read</button>{error && <p role="alert" className="text-danger">{error}</p>}{!items.length && <p>No notifications yet.</p>}{items.map(n => <article key={n.id} className="p-6 bg-card border border-border rounded-xl"><h2 className="font-bold">{!n.read && '● '}{n.title}</h2><p>{n.message}</p><p className="text-sm text-muted">{new Date(n.createdAt).toLocaleString()}</p><button disabled={busy} onClick={() => action(`/api/notifications/${n.id}`, 'DELETE')} className="text-primary mt-3">Dismiss</button></article>)}</div>;
}
