import React from 'react';
import CollectionManager from '../components/CollectionManager.tsx';
export default function Campaigns() { return <CollectionManager title="Campaign Drafts" path="/api/campaigns" field="name" description="Prepare and save WhatsApp campaign drafts. Delivery requires a configured messaging provider and recipient consent; saving does not send messages." />; }
