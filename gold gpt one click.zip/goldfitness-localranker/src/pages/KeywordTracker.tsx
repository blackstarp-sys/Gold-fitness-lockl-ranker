import React from 'react';
import CollectionManager from '../components/CollectionManager.tsx';
export default function KeywordTracker() { return <CollectionManager title="Tracked Keywords" path="/api/seo/keywords" field="keyword" description="Save keywords for each location. Automatic rank measurement requires a ranking provider integration." />; }
