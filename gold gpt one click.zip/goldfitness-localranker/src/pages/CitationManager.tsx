import React from 'react';
import CollectionManager from '../components/CollectionManager.tsx';
export default function CitationManager() { return <CollectionManager title="Citation Directory" path="/api/citations" field="platform" description="Track the directories where your business needs a listing. Saving a directory here does not submit an external listing." />; }
