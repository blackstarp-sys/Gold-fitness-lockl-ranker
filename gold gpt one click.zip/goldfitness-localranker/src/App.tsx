const Optimizer = React.lazy(() => import('./pages/Optimizer.tsx'));
import React, { Suspense } from 'react';
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import Layout from './components/Layout.tsx';
const Dashboard = React.lazy(() => import('./pages/Dashboard.tsx'));
const Reviews = React.lazy(() => import('./pages/Reviews.tsx'));
const Posts = React.lazy(() => import('./pages/Posts.tsx'));
const Analytics = React.lazy(() => import('./pages/Analytics.tsx'));
const Login = React.lazy(() => import('./pages/Login.tsx'));
const SocialConfig = React.lazy(() => import('./pages/SocialConfig.tsx'));
const BusinessProfile = React.lazy(() => import('./pages/BusinessProfile.tsx'));
const KeywordTracker = React.lazy(() => import('./pages/KeywordTracker.tsx'));
const Competitors = React.lazy(() => import('./pages/Competitors.tsx'));
const CitationManager = React.lazy(() => import('./pages/CitationManager.tsx'));
const WebsiteAudit = React.lazy(() => import('./pages/WebsiteAudit.tsx'));
const ReviewAutomation = React.lazy(() => import('./pages/ReviewAutomation.tsx'));
const ReplyTemplates = React.lazy(() => import('./pages/ReplyTemplates.tsx'));
const AIContentStudio = React.lazy(() => import('./pages/AIContentStudio.tsx'));
const AIImageGen = React.lazy(() => import('./pages/AIImageGen.tsx'));
const Programs = React.lazy(() => import('./pages/Campaigns.tsx'));
const WhatsApp = React.lazy(() => import('./pages/WhatsApp.tsx'));
const Settings = React.lazy(() => import('./pages/Settings.tsx'));

import ProtectedRoute from './components/ProtectedRoute.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { AuthProvider } from './context/AuthContext.tsx';
import { Loader2 } from 'lucide-react';

import './lib/i18n.ts';

const ManagePlan = React.lazy(() => import('./pages/ManagePlan.tsx'));
const Media = React.lazy(() => import('./pages/Media.tsx'));
const LocalRank = React.lazy(() => import('./pages/LocalRank.tsx'));
const Billing = React.lazy(() => import('./pages/Billing.tsx'));
const UsageCredits = React.lazy(() => import('./pages/UsageCredits.tsx'));
const Notifications = React.lazy(() => import('./pages/Notifications.tsx'));
const Diagnostics = React.lazy(() => import('./pages/Diagnostics.tsx'));

function AppContent() {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <Suspense fallback={
          <div className="flex h-screen w-full items-center justify-center bg-[#070B16]">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        }>
          <Routes>
            <Route path="/login" element={<Login />} />
            
            <Route element={<ProtectedRoute />}>
              <Route path="/" element={<Layout />}>
                <Route index element={<Navigate to="/dashboard" replace />} />
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="manage-plan" element={<Billing />} />
                
                <Route path="google-business" element={<BusinessProfile />} />
                <Route path="one-click-optimization" element={<Optimizer />} />
                <Route path="google-audit" element={<WebsiteAudit />} />
                <Route path="google-posts" element={<Posts />} />
                <Route path="reviews" element={<Reviews />} />
                <Route path="reply-templates" element={<ReplyTemplates />} />
                <Route path="media" element={<Media />} />

                <Route path="ai-mode" element={<AIContentStudio />} />
                <Route path="ai-media" element={<AIImageGen />} />
                <Route path="campaigns" element={<Programs />} />
                <Route path="social-config" element={<SocialConfig />} />
                <Route path="whatsapp" element={<WhatsApp />} />

                <Route path="local-rank" element={<LocalRank />} />
                <Route path="keywords" element={<KeywordTracker />} />
                <Route path="competitors" element={<Competitors />} />
                <Route path="citations" element={<CitationManager />} />
                <Route path="reports" element={<Analytics />} />

                <Route path="billing" element={<Billing />} />
                <Route path="usage" element={<UsageCredits />} />

                <Route path="notifications" element={<Notifications />} />
                <Route path="diagnostics" element={<Diagnostics />} />
                <Route path="settings" element={<Settings />} />

                {/* Legacy paths for compatibility */}
                <Route path="business-profile" element={<Navigate to="/google-business" replace />} />
                <Route path="audit" element={<Navigate to="/google-audit" replace />} />
                <Route path="ai-studio" element={<Navigate to="/ai-mode" replace />} />
                <Route path="ai-images" element={<Navigate to="/ai-media" replace />} />
                <Route path="analytics" element={<Navigate to="/reports" replace />} />
                <Route path="review-automation" element={<Navigate to="/one-click-optimization" replace />} />
              </Route>
            </Route>
            
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </Suspense>
      </ErrorBoundary>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
