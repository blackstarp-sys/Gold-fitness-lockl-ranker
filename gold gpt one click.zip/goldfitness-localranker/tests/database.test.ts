import test from 'node:test';
import assert from 'node:assert/strict';
import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import { upgradeDatabase } from '../src/db/upgrade.ts';
test('fresh database migration supports all app tables and is repeatable', async () => {
  const db = new PGlite();
  try {
    await upgradeDatabase(db);
    const tables = await db.query("SELECT count(*)::int AS count FROM information_schema.tables WHERE table_schema='public'");
    assert.equal((tables.rows[0] as any).count, 21);
    await upgradeDatabase(db);
    const user = await db.query("INSERT INTO users(uid,email) VALUES ('fresh','fresh@example.com') RETURNING id");
    await db.query("INSERT INTO business_locations(user_id,google_location_id,business_name) VALUES ($1,'locations/123','Test Gym')", [(user.rows[0] as any).id]);
  } finally { await db.close(); }
});
test('legacy numeric IDs upgrade preserves members of relationships and all row content', async () => {
  const db = new PGlite();
  try {
    for (const file of ['0000_cool_lily_hollister.sql','0001_previous_newton_destine.sql','0002_bumpy_rockslide.sql']) await db.exec(readFileSync(`drizzle/${file}`, 'utf8'));
    await db.query("INSERT INTO users(uid,email) VALUES ('old','old@example.com')");
    await db.query("INSERT INTO business_locations(user_id,google_location_id,business_name) VALUES (1,'locations/456','Legacy Gym')");
    await db.query("INSERT INTO reviews(location_id,google_review_id,reviewer_name,star_rating,comment) VALUES (1,'review-1','Customer',5,'Keep this review')");
    await upgradeDatabase(db);
    const rows = await db.query('SELECT r.comment,l.business_name,l.id FROM reviews r JOIN business_locations l ON l.id=r.location_id');
    assert.equal((rows.rows[0] as any).comment, 'Keep this review');
    assert.equal((rows.rows[0] as any).business_name, 'Legacy Gym');
    assert.match((rows.rows[0] as any).id, /^[0-9a-f-]{36}$/);
    await upgradeDatabase(db);
    assert.equal((await db.query('SELECT * FROM reviews')).rows.length, 1);
  } finally { await db.close(); }
});
