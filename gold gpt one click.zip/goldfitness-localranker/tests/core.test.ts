import test from 'node:test';
import assert from 'node:assert/strict';
import { validatePost, profileChecks } from '../src/server/validation.ts';
import { isPublicIPv4, analyzeHtml } from '../src/server/websiteAudit.ts';
import { normalizePerformance } from '../src/server/performance.ts';
const post = { summary: 'Visit our gym', locationId: 'c61e5f1c-824d-44ea-9952-630cfb123abc', scheduledFor: new Date(Date.now() + 3600000).toISOString() };
test('publishing rejects invalid content, dates, URLs and unsupported platforms', () => {
  assert.equal(validatePost(post, true), null);
  for (const body of [{ ...post, summary: 4 }, { ...post, summary: 'x'.repeat(1501) }, { ...post, scheduledFor: 'garbage' }, { ...post, scheduledFor: '2000-01-01' }, { ...post, mediaUrl: 'javascript:alert(1)' }, { ...post, platforms: ['instagram'] }]) assert.ok(validatePost(body, true));
});
test('website fetch address filter blocks private, loopback, reserved and metadata networks', () => {
  for (const ip of ['127.0.0.1','10.0.0.1','172.16.0.2','192.168.1.1','169.254.169.254','100.64.0.1','0.0.0.0','224.0.0.1','198.18.1.2','203.0.113.1','::1']) assert.equal(isPublicIPv4(ip), false, ip);
  assert.equal(isPublicIPv4('8.8.8.8'), true);
});
test('HTML audit distinguishes missing metadata from complete basic checks', () => {
  assert.equal(analyzeHtml('<html><h1>Hello</h1></html>', 'http://example.com').score, 13);
  const result = analyzeHtml(`<html lang="en"><title>Dhanus Gold Fitness Gym</title><meta content="Gym in Kengeri" name="description"><meta name="viewport" content="width=device-width"><link rel="canonical" href="https://example.com"><script type="application/ld+json">{}</script><h1>Gym</h1></html>`, 'https://example.com');
  assert.equal(result.score, 100);
});
test('optimization score reflects actual saved profile gaps', () => {
  assert.equal(profileChecks({}, 2, 0).score, 0);
  const full = { businessName: 'Gym', address: 'Kengeri', phone: '12345', websiteUri: 'https://example.com', description: 'a'.repeat(110), category: 'Gym', businessHours: { periods: ['Monday'] } };
  assert.equal(profileChecks(full, 0, 1).score, 100);
  assert.ok(profileChecks(full, 4, 0).score < 100);
});
test('performance API nested time series retain dates and combine impression types', () => {
  const point = (metric: string, value: string) => ({ dailyMetric: metric, timeSeries: { datedValues: [{ date: { year: 2026, month: 9, day: 1 }, value }] } });
  const rows = normalizePerformance({ multiDailyMetricTimeSeries: [{ dailyMetricTimeSeries: [point('BUSINESS_IMPRESSIONS_DESKTOP_MAPS', '10'), point('BUSINESS_IMPRESSIONS_MOBILE_MAPS', '20'), point('WEBSITE_CLICKS', '3')] }] });
  assert.equal(rows.length, 1); assert.equal(rows[0].profileViews, 30); assert.equal(rows[0].searchesMaps, 30); assert.equal(rows[0].websiteClicks, 3); assert.equal(rows[0].recordedDate.toISOString(), '2026-09-01T00:00:00.000Z');
});
