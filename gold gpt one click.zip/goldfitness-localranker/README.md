# GoldFitness LocalRanker — corrected project

This is a Node/Express + React/Vite application with PostgreSQL storage, Firebase login, Google Business OAuth and server-side Gemini generation.

## Start locally

1. Install Node 22.12+ (Node 24 was used for validation).
2. Run `npm ci`.
3. Copy `.env.example` to `.env` and fill in your real settings.
4. Check `firebase-applet-config.json` belongs to your Firebase project. Enable its Google sign-in provider and authorize your app domain in Firebase Authentication.
5. Back up your existing database, then run `npm run db:migrate`.
6. Run `npm run dev` and open http://localhost:3000.

Use the npm lockfile included here. The old Bun lockfile and historical code-rewrite scripts are not part of this corrected package.

## Required settings

- `DATABASE_URL`: PostgreSQL connection string. Passwords are preserved exactly; URL-encode reserved characters. TLS certificates are verified. For local PostgreSQL only, use `?sslmode=disable` or `DATABASE_SSL=disable`. Supply `DATABASE_CA_CERT` for a private CA.
- `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`: your own web OAuth client. Rotate the OAuth secret exposed in the original source; the embedded fallback has been removed.
- `APP_URL`: the public URL of this app, including HTTPS in production.
- `GOOGLE_REDIRECT_URI`: exactly `APP_URL/api/google/callback`, registered with your OAuth client.
- `GEMINI_API_KEY`: server-side Gemini API key. Optional until AI generation is used.
- `GEMINI_MODEL`: optional, defaults to `gemini-2.5-flash`.

Firebase identity is separate from Google Business authorization. Sign into the app, connect Google Business, grant `business.manage`, then sync your locations. Google Cloud must have the required Business Profile APIs and quota/access enabled. Code cannot grant quota or permissions to a Google project.

## Deployment

For a Node host such as Render:

- Build: `npm ci --include=dev && npm run build`
- Start: `npm start`
- Environment: `NODE_ENV=production`, configured database/OAuth/AI variables.
- Health route: `/api/live` checks the server; `/api/health` checks database reachability.
- Run `npm run db:migrate` as a controlled migration before starting the upgraded application.

This is a full-stack Node app; uploading only `dist` will not provide its API. Keep development dependencies installed because `tsx` and Vite are used by the supplied start workflow. The platform supplies `PORT`.

Scheduled Google posts are processed every five minutes while the server is running. A database claim prevents simultaneous workers publishing the same pending row. A crash after claiming leaves `PROCESSING`; inspect Google and the database before manually retrying, because publication may have succeeded. There is no automatic recovery of ambiguous publication outcomes. Do not assume sleeping free hosting will run jobs on schedule.

## Database upgrade

`npm run db:migrate` creates the current 21-table schema on a fresh database or upgrades the supplied legacy numeric-ID schema. It preserves existing records and converts location/review/post IDs to UUIDs, including linked location IDs. Missing columns and foreign keys are added transactionally. A failure rolls back the transaction.

The tests cover the exact three legacy SQL snapshots supplied in the ZIP. Customized live schemas may need further migration work. The upgrade refuses unsupported ID types and unknown tables referencing converted IDs. Back up first. Old public numeric IDs change; do not retain external links based on them. Avoid rerunning the legacy `drizzle/*.sql` files on an upgraded database.

## What now works

- One-click local profile completeness checks, per-location action links, report history, JSON export and a saved notification.
- Basic website HTML audits, saved findings/history, private-network protection and bounded downloads.
- AI content drafts in English, Kannada and Hindi, selectable content types, saved generation history and copy/edit controls.
- Saved review templates; saved keyword, competitor and citation lists; saved campaign drafts.
- Real notification read/dismiss actions, replacing sample notifications.
- Google review pagination and corrected dated performance series ingestion.
- Protected Google authorization state, account-scoped cache writes and redacted token responses.
- Validated post scheduling and concurrent worker claims.

Profile completeness and HTML audit percentages are local checklist scores, not Google rank predictions. Profile edits save to the app's database; this version does not PATCH the live Google profile. AI text must be reviewed before use.

## Remaining integrations / limits

- Google/Firebase login, real Google syncing/posting/replies and Gemini output need end-to-end testing against your configured accounts.
- Automatic rank-grid measurement, competitor discovery and citation submission need actual provider integrations. No generated ranks are presented as measured results.
- AI image generation, media upload/sync and storage are not implemented.
- WhatsApp templates and campaign drafts persist, but Meta template approval, recipient delivery, webhooks and automation are not implemented. Other social platform OAuth/publishing is not implemented.
- Billing checkout, invoices and payments are not implemented. The previous sample payment card/renewal details were removed.
- One-click checks guide the owner to improvements; they do not automatically change a public website or Google listing.
- AI billing is serialized and failed model calls are not charged. Generation and subsequent persistence are not one atomic external transaction; a database failure after generation/charging can require manual reconciliation. Rate controls are not a distributed billing quota service.
- Existing tokens remain stored in PostgreSQL; restrict database access and use encryption/backups provided by your host.

See `FIXES-AND-VALIDATION.md` for the audit and verification evidence.
