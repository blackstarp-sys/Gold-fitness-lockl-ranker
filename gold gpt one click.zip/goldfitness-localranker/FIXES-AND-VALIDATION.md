# Engineering audit and validation

## Corrected defects

1. Dependency manifest/lockfile mismatch prevented `npm ci`; lockfile regenerated and clean install verified.
2. Removed embedded Google OAuth client secret and environment-client overrides.
3. Replaced forgeable base64 user-ID OAuth state with random, hashed server-held, expiring, browser-bound, single-use state.
4. Removed Firebase-to-database automatic relinking by email; identity remains bound to the verified UID.
5. Database failures now produce a service error instead of being reported as an invalid login token.
6. Removed access/refresh token fields from profile and social-account API responses.
7. Removed hard-coded Google account injection and synthetic account/location creation. Manual account selection verifies provider access.
8. Replaced invalid `ON CONFLICT` account writes targeting a nonexistent unique index with locked, user-scoped updates.
9. Removed attempts to reuse expired Google tokens after refresh failure; unknown expiry requires refresh.
10. Removed mutation of bracket characters in database passwords; enabled verified TLS.
11. Added a tested current-schema initializer and legacy numeric-to-UUID upgrade.
12. Made Gemini client creation lazy, added explicit key configuration, model override, timeout and empty-output handling.
13. Moved credit charging after successful generation; charge reads/writes are serialized in a database transaction. Reviews are ownership-checked before generation.
14. Added validation for post contents, dates, image URLs and supported platform choices.
15. Added atomic pending-post claims and the missing account ID in scheduled Google publishing calls.
16. Fixed performance metric names, repeated query parameters, required date range, nested response parsing and day-based storage. Latest analytics rows now sort chronologically after selection.
17. Added review pagination beyond the first 50 reviews.
18. Added JSON API 404/error responses, malformed-body handling, no-store headers and same-origin authenticated fetch enforcement.
19. Removed an unnecessary Firestore probe during client startup.
20. Split page loading into lazy routes.
21. Replaced simulated rank grids, fictional notifications/payment details and fake social/WhatsApp connection success with actual data or explicit implementation status.
22. Replaced a review-discount request template with a neutral honest-feedback request.

## Added functional workflows

- Local profile optimization checklist/report export.
- Basic website HTML auditing and persisted findings.
- AI draft generation and history.
- Persisted review templates.
- Persisted keyword, competitor, citation and campaign-draft creation/deletion.
- Persisted notification actions.

## Verification

- `npm ci --ignore-scripts --no-audit --no-fund --prefer-offline`: passed (785 packages).
- TypeScript `tsc --noEmit`: passed.
- Production Vite/PWA build: passed. A large-bundle warning remains; it is not a build error.
- Seven regression tests: passed. They cover post validation, private-network filters, HTML scoring, profile scoring, Google metrics parsing, new-schema migration and legacy migration preserving relationships. Database tests run PostgreSQL through PGlite.
- Local production HTTP smoke checks: `/api/live` 200; protected locations, optimization and AI history 401 without credentials; unknown API 404; dashboard HTML 200; malformed JSON 400.

A successful build and these tests do not establish that every page or live integration is error-free. No live business data was accessed, no Google post/reply was published, no campaign was sent, and no production database was migrated.

## Reference documentation checked

- Google OAuth web-server flow: https://developers.google.com/identity/protocols/oauth2/web-server
- Business Profile performance API: https://developers.google.com/my-business/reference/performance/rest/v1/locations/fetchMultiDailyMetricsTimeSeries
- Google review incentives policy: https://support.google.com/contributionpolicy/answer/16597558
